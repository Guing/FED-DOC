const imgCode = {
    global_commendcourse : 'C56R35638I',
    global_guanfangcode : 'QATTS2KB5K',
    global_teachercode : 'YE1AT22QE3'
}
export default imgCode